# Compact prefill metadata and progressive exact KV study

Status: **completed**

Exact original-BF16 page-local progressive coding with zero-payload known-field summaries, 1/2/4-bit actual-prefill hints, page sharing and exact same-page K-to-V controls. Real complete CPU-reference packets and full state count. Full-cache/concurrency numbers are estimates, not measured serving or GPU codec gains.

Frozen DEV winner: **field_baseline**.

| Case | Tokens | Method | Packet reduction | Net full-cache estimate | Decode seconds |
|---|---:|---|---:|---:|---:|
| test_training_holdout_canal_gates | 64 | frozen_exponent_control | -21.655% | -120.148% | 0.013 |
| test_training_holdout_canal_gates | 64 | field_baseline | -8.612% | -10.352% | 0.001 |
| test_training_holdout_canal_gates | 64 | lsb_local_none | -46.552% | -127.893% | 0.002 |
| test_training_holdout_canal_gates | 64 | lsb_pool_none | -46.454% | -127.789% | 0.001 |
| test_training_holdout_canal_gates | 64 | lsb_pool_kv2 | -46.552% | -132.031% | 0.002 |
| test_training_holdout_canal_gates | 64 | lsb_pool_hidden1 | -46.844% | -132.410% | 0.002 |
| test_training_holdout_canal_gates | 64 | lsb_pool_hidden2 | -46.942% | -132.520% | 0.002 |
| test_training_holdout_canal_gates | 64 | lsb_pool_hidden4 | -47.137% | -132.709% | 0.002 |
| test_training_holdout_canal_gates | 64 | lsb_page_hidden2 | -46.698% | -132.257% | 0.002 |
| test_training_holdout_canal_gates | 64 | lsb_page_kv2 | -46.307% | -131.775% | 0.002 |
| test_training_holdout_canal_gates | 64 | lsb_kfirst_none | -44.421% | -125.775% | 0.001 |
| test_training_holdout_canal_gates | 64 | lsb_kfirst_kv2 | -44.519% | -130.023% | 0.002 |
| test_training_holdout_canal_gates | 64 | lsb_kfirst_hidden2 | -44.910% | -130.499% | 0.002 |
| test_training_holdout_canal_gates | 64 | msb_pool_none | -46.631% | -127.960% | 0.002 |
| test_training_holdout_canal_gates | 64 | msb_pool_kv2 | -46.729% | -132.196% | 0.002 |
| test_training_holdout_canal_gates | 64 | msb_pool_hidden2 | -47.119% | -132.690% | 0.002 |
| test_training_holdout_interval_merge | 64 | frozen_exponent_control | -21.906% | -120.398% | 0.015 |
| test_training_holdout_interval_merge | 64 | field_baseline | -8.588% | -10.327% | 0.001 |
| test_training_holdout_interval_merge | 64 | lsb_local_none | -46.625% | -127.966% | 0.002 |
| test_training_holdout_interval_merge | 64 | lsb_pool_none | -46.527% | -127.863% | 0.002 |
| test_training_holdout_interval_merge | 64 | lsb_pool_kv2 | -46.625% | -132.104% | 0.002 |
| test_training_holdout_interval_merge | 64 | lsb_pool_hidden1 | -46.918% | -132.483% | 0.002 |
| test_training_holdout_interval_merge | 64 | lsb_pool_hidden2 | -47.015% | -132.593% | 0.001 |
| test_training_holdout_interval_merge | 64 | lsb_pool_hidden4 | -47.211% | -132.782% | 0.003 |
| test_training_holdout_interval_merge | 64 | lsb_page_hidden2 | -46.771% | -132.330% | 0.002 |
| test_training_holdout_interval_merge | 64 | lsb_page_kv2 | -46.381% | -131.848% | 0.002 |
| test_training_holdout_interval_merge | 64 | lsb_kfirst_none | -44.421% | -125.775% | 0.002 |
| test_training_holdout_interval_merge | 64 | lsb_kfirst_kv2 | -44.519% | -130.023% | 0.002 |
| test_training_holdout_interval_merge | 64 | lsb_kfirst_hidden2 | -44.910% | -130.499% | 0.002 |
| test_training_holdout_interval_merge | 64 | msb_pool_none | -46.533% | -127.863% | 0.002 |
| test_training_holdout_interval_merge | 64 | msb_pool_kv2 | -46.631% | -132.098% | 0.002 |
| test_training_holdout_interval_merge | 64 | msb_pool_hidden2 | -47.021% | -132.593% | 0.002 |

All reported storage numbers use real complete packets. Models, lookup parameters, calibration, hint padding, raw fallbacks and all framing are charged. TEST cannot change DEV selection.

A producer-information gain requires reduced learned-stage payload against the same-layout no-hint/KV control. Descriptive header/name length, hint cost and full state deltas are reported separately.

The current reference performs entropy coding on CPU and probability inference on the selected device. All raw KV remains resident during capture. Timings include diagnostic staging; no fused GPU decoder, SSD transfer, concurrent admission or serving speedup is established.

Full DEV continuation checks: lsb_kfirst_none: ok, lsb_pool_none: ok, lsb_pool_hidden2: ok, msb_pool_hidden2: ok, lsb_kfirst_hidden2: ok, field_baseline: ok

Raw categorical hints are retained under hints/ for future TRAIN-only fitting and DEV/TEST sensitivity analysis. Raw KV and hidden captures are not exported.
