# Prefill coset training coverage and duration

Status: **completed**

Fixed rank/width, same TRAIN data, same seed and shared cosine horizon. Random versus coverage-balanced channel sampling crossed with short versus long training. Actual prefill DEV probes; fresh synthetic TEST holdouts. CPU packet coding and selected-device neural work, exact original BF16, complete state charged. No early stopping or TEST-driven selection; sampled storage estimates, no serving/capacity claim.

| Arm | Case | Tokens | Method | Packet reduction | Net estimate | Short groups |
|---|---|---:|---|---:|---:|---:|
| random_short | test_training_holdout_canal_gates | 64 | frozen_exponent_control | 4.388% | -94.092% | 0 |
| random_short | test_training_holdout_canal_gates | 64 | field_baseline | 10.254% | 8.514% | 0 |
| random_short | test_training_holdout_canal_gates | 64 | coset_none_syndrome | 9.424% | -189.941% | 0 |
| random_short | test_training_holdout_canal_gates | 64 | coset_none_positions | 9.424% | -189.941% | 0 |
| random_short | test_training_holdout_canal_gates | 64 | coset_kv_syndrome | 6.299% | -204.102% | 0 |
| random_short | test_training_holdout_canal_gates | 64 | coset_kv_positions | 6.299% | -204.102% | 0 |
| random_short | test_training_holdout_canal_gates | 64 | coset_hidden_syndrome | 6.201% | -204.401% | 0 |
| random_short | test_training_holdout_canal_gates | 64 | coset_hidden_positions | 6.201% | -204.401% | 0 |
| random_short | test_training_holdout_interval_merge | 64 | frozen_exponent_control | 4.138% | -94.342% | 0 |
| random_short | test_training_holdout_interval_merge | 64 | field_baseline | 10.150% | 8.411% | 0 |
| random_short | test_training_holdout_interval_merge | 64 | coset_none_syndrome | 9.320% | -190.045% | 0 |
| random_short | test_training_holdout_interval_merge | 64 | coset_none_positions | 9.320% | -190.045% | 0 |
| random_short | test_training_holdout_interval_merge | 64 | coset_kv_syndrome | 6.195% | -204.205% | 0 |
| random_short | test_training_holdout_interval_merge | 64 | coset_kv_positions | 6.195% | -204.205% | 0 |
| random_short | test_training_holdout_interval_merge | 64 | coset_hidden_syndrome | 6.097% | -204.504% | 0 |
| random_short | test_training_holdout_interval_merge | 64 | coset_hidden_positions | 6.097% | -204.504% | 0 |
| random_long | test_training_holdout_canal_gates | 64 | frozen_exponent_control | 4.388% | -94.080% | 0 |
| random_long | test_training_holdout_canal_gates | 64 | field_baseline | 10.254% | 8.514% | 0 |
| random_long | test_training_holdout_canal_gates | 64 | coset_none_syndrome | 9.424% | -198.859% | 0 |
| random_long | test_training_holdout_canal_gates | 64 | coset_none_positions | 9.424% | -198.859% | 0 |
| random_long | test_training_holdout_canal_gates | 64 | coset_kv_syndrome | 6.299% | -213.031% | 0 |
| random_long | test_training_holdout_canal_gates | 64 | coset_kv_positions | 6.299% | -213.031% | 0 |
| random_long | test_training_holdout_canal_gates | 64 | coset_hidden_syndrome | 6.201% | -213.348% | 0 |
| random_long | test_training_holdout_canal_gates | 64 | coset_hidden_positions | 6.201% | -213.348% | 0 |
| random_long | test_training_holdout_interval_merge | 64 | frozen_exponent_control | 4.138% | -94.330% | 0 |
| random_long | test_training_holdout_interval_merge | 64 | field_baseline | 10.150% | 8.411% | 0 |
| random_long | test_training_holdout_interval_merge | 64 | coset_none_syndrome | 9.320% | -198.962% | 0 |
| random_long | test_training_holdout_interval_merge | 64 | coset_none_positions | 9.320% | -198.962% | 0 |
| random_long | test_training_holdout_interval_merge | 64 | coset_kv_syndrome | 6.195% | -213.135% | 0 |
| random_long | test_training_holdout_interval_merge | 64 | coset_kv_positions | 6.195% | -213.135% | 0 |
| random_long | test_training_holdout_interval_merge | 64 | coset_hidden_syndrome | 6.097% | -213.452% | 0 |
| random_long | test_training_holdout_interval_merge | 64 | coset_hidden_positions | 6.097% | -213.452% | 0 |
| balanced_short | test_training_holdout_canal_gates | 64 | frozen_exponent_control | 4.388% | -94.092% | 0 |
| balanced_short | test_training_holdout_canal_gates | 64 | field_baseline | 10.254% | 8.514% | 0 |
| balanced_short | test_training_holdout_canal_gates | 64 | coset_none_syndrome | 9.424% | -190.900% | 0 |
| balanced_short | test_training_holdout_canal_gates | 64 | coset_none_positions | 9.424% | -190.900% | 0 |
| balanced_short | test_training_holdout_canal_gates | 64 | coset_kv_syndrome | 6.299% | -205.060% | 0 |
| balanced_short | test_training_holdout_canal_gates | 64 | coset_kv_positions | 6.299% | -205.060% | 0 |
| balanced_short | test_training_holdout_canal_gates | 64 | coset_hidden_syndrome | 6.201% | -205.371% | 0 |
| balanced_short | test_training_holdout_canal_gates | 64 | coset_hidden_positions | 6.201% | -205.371% | 0 |
| balanced_short | test_training_holdout_interval_merge | 64 | frozen_exponent_control | 4.138% | -94.342% | 0 |
| balanced_short | test_training_holdout_interval_merge | 64 | field_baseline | 10.150% | 8.411% | 0 |
| balanced_short | test_training_holdout_interval_merge | 64 | coset_none_syndrome | 9.320% | -191.003% | 0 |
| balanced_short | test_training_holdout_interval_merge | 64 | coset_none_positions | 9.320% | -191.003% | 0 |
| balanced_short | test_training_holdout_interval_merge | 64 | coset_kv_syndrome | 6.195% | -205.164% | 0 |
| balanced_short | test_training_holdout_interval_merge | 64 | coset_kv_positions | 6.195% | -205.164% | 0 |
| balanced_short | test_training_holdout_interval_merge | 64 | coset_hidden_syndrome | 6.097% | -205.475% | 0 |
| balanced_short | test_training_holdout_interval_merge | 64 | coset_hidden_positions | 6.097% | -205.475% | 0 |
| balanced_long | test_training_holdout_canal_gates | 64 | frozen_exponent_control | 4.388% | -94.104% | 0 |
| balanced_long | test_training_holdout_canal_gates | 64 | field_baseline | 10.254% | 8.514% | 0 |
| balanced_long | test_training_holdout_canal_gates | 64 | coset_none_syndrome | 9.424% | -199.829% | 0 |
| balanced_long | test_training_holdout_canal_gates | 64 | coset_none_positions | 9.424% | -199.829% | 0 |
| balanced_long | test_training_holdout_canal_gates | 64 | coset_kv_syndrome | 6.299% | -213.989% | 0 |
| balanced_long | test_training_holdout_canal_gates | 64 | coset_kv_positions | 6.299% | -213.989% | 0 |
| balanced_long | test_training_holdout_canal_gates | 64 | coset_hidden_syndrome | 6.201% | -214.294% | 0 |
| balanced_long | test_training_holdout_canal_gates | 64 | coset_hidden_positions | 6.201% | -214.294% | 0 |
| balanced_long | test_training_holdout_interval_merge | 64 | frozen_exponent_control | 4.138% | -94.354% | 0 |
| balanced_long | test_training_holdout_interval_merge | 64 | field_baseline | 10.150% | 8.411% | 0 |
| balanced_long | test_training_holdout_interval_merge | 64 | coset_none_syndrome | 9.320% | -199.933% | 0 |
| balanced_long | test_training_holdout_interval_merge | 64 | coset_none_positions | 9.320% | -199.933% | 0 |
| balanced_long | test_training_holdout_interval_merge | 64 | coset_kv_syndrome | 6.195% | -214.093% | 0 |
| balanced_long | test_training_holdout_interval_merge | 64 | coset_kv_positions | 6.195% | -214.093% | 0 |
| balanced_long | test_training_holdout_interval_merge | 64 | coset_hidden_syndrome | 6.097% | -214.398% | 0 |
| balanced_long | test_training_holdout_interval_merge | 64 | coset_hidden_positions | 6.097% | -214.398% | 0 |

All four arms and final requested updates are prespecified. DEV probes never stop training or select checkpoints. Every child run retains its packet, generation, timing, ablation and complete state-accounting logs.

Use scripts/review_coset_training_results.py to verify the four-arm evidence. No serving speedup or research priority is established.
