# Prefill metadata and exact vector-coset study

Status: **completed**

Exact original-BF16 independent pages using TRAIN-fitted metadata-conditioned bit predictors, selected mantissa residues and verified 31-bit vector-coset/sparse-position corrections. All measured packet and full state bytes count. CPU reference coding, selected-device neural work, sampled full-cache estimates; no compact attention, speedup, serving-capacity or novelty claim.

| Case | Tokens | Method | Residue bits | Sample packet savings | Net full-cache estimate |
|---|---:|---|---:|---:|---:|
| test_training_holdout_canal_gates | 64 | frozen_exponent_control (ok) | — | 4.39% | -94.09% |
| test_training_holdout_canal_gates | 64 | field_baseline (ok) | 7 | 10.25% | 8.51% |
| test_training_holdout_canal_gates | 64 | coset_none_syndrome (ok) | 6 | 9.42% | -190.90% |
| test_training_holdout_canal_gates | 64 | coset_none_positions (ok) | 6 | 9.42% | -190.90% |
| test_training_holdout_canal_gates | 64 | coset_kv_syndrome (ok) | 6 | 6.30% | -205.06% |
| test_training_holdout_canal_gates | 64 | coset_kv_positions (ok) | 6 | 6.30% | -205.06% |
| test_training_holdout_canal_gates | 64 | coset_hidden_syndrome (ok) | 6 | 6.20% | -205.37% |
| test_training_holdout_canal_gates | 64 | coset_hidden_positions (ok) | 6 | 6.20% | -205.37% |
| test_training_holdout_interval_merge | 64 | frozen_exponent_control (ok) | — | 4.14% | -94.34% |
| test_training_holdout_interval_merge | 64 | field_baseline (ok) | 7 | 10.15% | 8.41% |
| test_training_holdout_interval_merge | 64 | coset_none_syndrome (ok) | 6 | 9.32% | -191.00% |
| test_training_holdout_interval_merge | 64 | coset_none_positions (ok) | 6 | 9.32% | -191.00% |
| test_training_holdout_interval_merge | 64 | coset_kv_syndrome (ok) | 6 | 6.20% | -205.16% |
| test_training_holdout_interval_merge | 64 | coset_kv_positions (ok) | 6 | 6.20% | -205.16% |
| test_training_holdout_interval_merge | 64 | coset_hidden_syndrome (ok) | 6 | 6.10% | -205.47% |
| test_training_holdout_interval_merge | 64 | coset_hidden_positions (ok) | 6 | 6.10% | -205.47% |

Residue widths are selected on complete DEV packet bytes and frozen before TEST. Candidates keep their side code even if every correction group escapes; no learned whole-page fallback hides the tested path.

The syndrome and sparse-position representations are matched controls, not stackable savings. Actual packet components, bitplane/K/V error-group histograms, code-use ablations, layer/position breakdowns and model/packet identities are in results.json and decision_summary.json.

Packet coding runs on CPU. Code extraction and bit prediction run on the selected device, with diagnostic staging. Instrumented prefill includes all encoders and retains full raw KV; no isolated prefill overhead, fused GPU decoder, SSD transfer or concurrent-serving benefit is measured.

Full DEV packet-only continuation checks:

- coset_none_syndrome: ok
- coset_kv_syndrome: ok
- coset_hidden_syndrome: ok
